require "mkmf"

create_makefile("jfk_reader")
